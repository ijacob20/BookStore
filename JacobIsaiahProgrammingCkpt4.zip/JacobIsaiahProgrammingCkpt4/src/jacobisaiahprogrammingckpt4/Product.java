/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jacobisaiahprogrammingckpt4;

/**
 *
 * @author Isaiah
 */
public class Product {
    private String title;
    private double price;
    private String seller;
    private boolean newItem;

    /**
     * Constructor for Product class
     * @param title title of the product
     * @param price price of the product
     * @param seller seller of the product
     * @param newItem boolean - whether the item is new or not
     */
    public Product(String title, double price, String seller, boolean newItem) {
        this.title = title;
        this.price = price;
        this.title = title;
        this.seller = seller;
        this.newItem = newItem;
    }

    /**
     * Method to get title
     * @return title
     */
    public String getTitle() {
        return title;
    }

    /**
     * Method to set title
     * @param title title of the product
     */
    public void setTitle(String title) {
        this.title = title;
    }

    /**
     * Method to get price
     * @return price
     */
    public double getPrice() {
        return price;
    }

    /**
     * Method to set price
     * @param price price of the product
     */
    public void setPrice(int price) {
        this.price = price;
    }

    /**
     * Method to get seller
     * @return seller
     */
    public String getSeller() {
        return seller;
    }

    /**
     * Method to set seller
     * @param seller Manufacturer name
     */
    public void setSeller(String seller) {
        this.seller = seller;
    }

    /**
     * Method to check whether product is new
     * @return true
     */
    public boolean isNewItem() {
        return newItem;
    }

    /**
     * Method to set condition of product
     * @param newItem boolean - whether the item is new - true if new
     */
    public void setNewItem(boolean newItem) {
        this.newItem = newItem;
    }
    
    /**
     * Method to display information of product
     */
    /** (old now)
    public void display(){
        System.out.println("Title: " + this.getTitle() + "\tSeller: " + this.getSeller());
        System.out.println("Price: $" + this.getPrice());
        System.out.println("New? " + this.isNewItem());
    }
    */ 
    public String display(){
        return this.getTitle() + " - " + this.getSeller() + " ($" + this.getPrice() + ")";
    }
    
}
