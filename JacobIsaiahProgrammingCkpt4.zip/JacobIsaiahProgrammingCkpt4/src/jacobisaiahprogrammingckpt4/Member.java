/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jacobisaiahprogrammingckpt4;

/**
 *
 * @author Isaiah
 */
public class Member {
    private String firstName;
    private String lastName;
    protected double totalAmountSpent; // set to protected in order for PremiumMembers class to be able to access this.totalAmountSpent

    /**
     * Constructor for Member class
     * @param firstName Member's first name
     * @param lastName Member's last name
     * @param totalAmountSpent total amount spent of member
     */
    public Member(String firstName, String lastName, double totalAmountSpent) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.totalAmountSpent = totalAmountSpent;
    }
    
    /**
     * Method to get first name of member
     * @return firstName
     */
    public String getFirstName() {
        return firstName;
    }

    /**
     * Method to set first name of member
     * @param firstName member's first name
     */
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    /**
     * Method to get member's last name
     * @return lastName
     */
    public String getLastName() {
        return lastName;
    }

    /**
     * Method to set member's last name
     * @param lastName member's last name
     */
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    /**
     * Method to get member's total amount spent
     * @return totalAmountSpent
     */
    public double getTotalAmountSpent() {
        return totalAmountSpent;
    }

    /**
     * Method to set member's total amount spent
     * @param totalAmountSpent member's total amount spent
     */
    public void setTotalAmountSpent(double totalAmountSpent) {
        this.totalAmountSpent = totalAmountSpent;
    }
    
    /**
     * Method to display members and their information
     */
    /** (old now)
    public void display(){
        System.out.println("Name: " + this.getFirstName() + " " + this.getLastName());
        System.out.println("Amount spent: $" + this.getTotalAmountSpent());
    }
    */
    
    public String display() {
        return this.getFirstName() + " " + this.getLastName();
    }
    
    /**
     * Method to add a purchase to a member
     * @param product product that is being purchased
     */
    public void addPurchase(Product product){
        this.totalAmountSpent = this.totalAmountSpent + product.getPrice();
    }
    
}
