/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jacobisaiahprogrammingckpt4;

/**
 *
 * @author Isaiah
 */
public class CDs extends Product {
    private String artistName;
    private int yearReleased;

    /**
     * Constructor for CDs class
     * @param title title of product
     * @param price price of product
     * @param seller seller/manufacturer of product
     * @param newItem whether item is new or not
     * @param artistName Name of the artist
     * @param yearReleased Year CD was released
     */
    public CDs(String title, double price, String seller, boolean newItem, String artistName, int yearReleased) {
        super(title, price, seller, newItem);
        this.artistName = artistName;
        this.yearReleased = yearReleased;
    }

    /**
     * Method to get artist's name
     * @return artist's name
     */
    public String getArtistName() {
        return artistName;
    }

    /**
     * Method to set artist's name
     * @param artistName artist's name
     */
    public void setArtistName(String artistName) {
        this.artistName = artistName;
    }

    /**
     * Method to get year CD released
     * @return yearReleased
     */
    public int getYearReleased() {
        return yearReleased;
    }

    /**
     * Method to set year CD released
     * @param yearReleased year CD released
     */
    public void setYearReleased(int yearReleased) {
        this.yearReleased = yearReleased;
    }
    /**
    @Override
    public void display(){
        System.out.println("Title: " + this.getTitle() + "\tSeller: " + this.getSeller());
        System.out.println("Price: $" + this.getPrice());
        System.out.println("New? " + this.isNewItem());
        System.out.println("Artist: " + this.artistName);
        System.out.println("Year yeleased: " + this.getYearReleased());
    }
    */ 
    public String display(){
        return this.getTitle() + " by " + this.getArtistName() + " (" + this.getYearReleased() + ")" + " " + "($" + this.getPrice() + ")";
    }
    
}
