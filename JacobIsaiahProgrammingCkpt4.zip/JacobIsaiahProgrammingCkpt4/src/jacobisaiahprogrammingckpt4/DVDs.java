/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jacobisaiahprogrammingckpt4;

/**
 *
 * @author Isaiah
 */
public class DVDs extends Product {
    private String director;
    private int releaseDate;
    private String resolution;

    /**
     * Constructor for DVDs class
     * @param title title of product
     * @param price price of product
     * @param seller seller/manufacturer of product
     * @param newItem whether product is new or not
     * @param director director of film
     * @param releaseDate year film was released
     * @param resolution DVD quality (4k? 1080p? Bluray? etc)
     */
    public DVDs(String title, double price, String seller, boolean newItem, String director, int releaseDate, String resolution) {
        super(title, price, seller, newItem);
        this.director = director;
        this.releaseDate = releaseDate;
        this.resolution = resolution;
    }

    /**
     * Method to get director of film
     * @return director name
     */
    public String getDirector() {
        return director;
    }

    /**
     * Method to set director of film
     * @param director name of the director
     */
    public void setDirector(String director) {
        this.director = director;
    }

    /**
     * Method to get release date of film
     * @return year of release
     */
    public int getReleaseDate() {
        return releaseDate;
    }

    /**
     * Method to set release date of film
     * @param releaseDate year film was released
     */
    public void setReleaseDate(int releaseDate) {
        this.releaseDate = releaseDate;
    }

    /**
     * Method to get resolution of film
     * @return resolution
     */
    public String getResolution() {
        return resolution;
    }

    /**
     * Method to set resolution of film
     * @param resolution picture quality of DVD
     */
    public void setResolution(String resolution) {
        this.resolution = resolution;
    }
    
    /**
    @Override
    public void display(){
        System.out.println("Title: " + this.getTitle() + "\tSeller: " + this.getSeller());
        System.out.println("Price: $" + this.getPrice());
        System.out.println("New? " + this.isNewItem());
        System.out.println("Director: " + this.getDirector());
        System.out.println("Release date: " + this.getReleaseDate());
    }
    */
    public String display(){
        return this.getTitle() + " by " + this.getDirector() + "  (" + this.getReleaseDate() + ")" + " " + "($" + this.getPrice() + ")";
    }
    
}
