/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jacobisaiahprogrammingckpt4;

import java.awt.Color;
import java.util.Scanner;

/**
 *
 * @author Isaiah
 */
public class Main {
    public static void main(String[] args) {
        BookStore store1 = new BookStore("Barnes & Noble"); // creates a BookStore object
        
        Product p1 = new Product("Toy car", 10, "Hot Wheels", true); // creates products objects (products, books, CDs, DVDs)
        Product p2 = new Product("Scissors", 7.99, "Tools Inc", true);
        Books b1 = new Books("The Great Gatsby", 25, "Classic Books Inc", false, "F. Scott", "Fitzgerald", 1925);
        CDs c1 = new CDs("Purple Rain", 14.99, "Real Records", false, "Prince", 1984);
        DVDs d1 = new DVDs("The Dark Knight", 34.99, "4k Classics", false, "Christopher Nolan", 2008, "4k");
        
        store1.inventory.add(p1); // adds products to the store's inventory
        store1.inventory.add(p2);
        store1.inventory.add(b1);
        store1.inventory.add(c1);
        store1.inventory.add(d1);
        
        
        Member m1 = new Member("Isaiah", "Jacob", 0); // adds member objects
        PremiumMembers m2 = new PremiumMembers("Bruce", "Wayne", 0, "Cash", true);
        store1.memberList.add(m1); // adds members to the store's member list(arrayList)
        store1.memberList.add(m2);
        
        // Menu Code Starts

        Menu BookStoreMenu = new Menu(store1);
        BookStoreMenu.setVisible(true);
        
        
        
    }
}
