/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jacobisaiahprogrammingckpt4;

import java.util.ArrayList;

/**
 *
 * @author Isaiah
 */
public class BookStore {
    private String storeName;
    public ArrayList<Product> inventory = new ArrayList(); // inventory list that stores products objects
    public ArrayList<Member> memberList = new ArrayList(); // member list that stores member objects
    private String welcomeMemberFirstName; //  stored in bookstore in order to get welcome back message from Jframe to another Jframe (LoginMenu to PurchaseMenu)
    private int globalMemberIdentifer; // stored in bookstore in order to transfer purchase information to the correct member

    /**
     * Constructor for BookStore
     * @param storeName name of the store
     */
    public BookStore(String storeName) {
        this.storeName = storeName;
        inventory = new ArrayList();
        memberList = new ArrayList();
    }

    /**
     * Method to get store name
     * @return store name
     */
    public String getStoreName() {
        return storeName;
    }

    /**
     * Method to set store name
     * @param storeName name of the store
     */
    public void setStoreName(String storeName) {
        this.storeName = storeName;
    }

    /**
     * Method to get inventory
     * @return inventory
     */
    public ArrayList<Product> getInventory() {
        return inventory;
    }

    /**
     * Method to set inventory
     * @param inventory inventory arrayList
     */
    public void setInventory(ArrayList<Product> inventory) {
        this.inventory = inventory;
    }

    /**
     * Method to get list of members
     * @return memberList list of members
     */
    public ArrayList<Member> getMemberList() {
        return memberList;
    }

    /**
     * Method to set list of members
     * @param memberList list of members
     */
    public void setMemberList(ArrayList<Member> memberList) {
        this.memberList = memberList;
    }
    
    /**
     * Method to add a member
     * @param member member who is being added
     * @param store store that member is being added to
     */
    public void addMember(Member member, BookStore store){
        store.memberList.add(member);
    }
    
    /**
     * Method to remove a member
     * @param member member who is being removed
     * @param store store that member is being removed from
     */
    public void removeMember(Member member, BookStore store){
        store.memberList.remove(member);
    }

    public String getWelcomeMemberFirstName() {
        return welcomeMemberFirstName;
    }

    public void setWelcomeMemberFirstName(String welcomeMemberFirstName) {
        this.welcomeMemberFirstName = welcomeMemberFirstName;
    }

    public int getGlobalMemberIdentifer() {
        return globalMemberIdentifer;
    }

    public void setGlobalMemberIdentifer(int globalMemberIdentifer) {
        this.globalMemberIdentifer = globalMemberIdentifer;
    }
    
    
}
