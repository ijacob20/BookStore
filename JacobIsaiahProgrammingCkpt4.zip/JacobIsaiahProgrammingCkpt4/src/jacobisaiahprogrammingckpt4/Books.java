/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jacobisaiahprogrammingckpt4;

/**
 *
 * @author Isaiah
 */
public class Books extends Product {
    private String authorFirstName;
    private String authorLastName;
    private int yearPublished;

    /**
     * Constructor for Books class
     * @param title title of product
     * @param price price of product
     * @param seller seller or manufacturer of product
     * @param newItem is product new? true for new
     * @param authorFirstName Author's first name
     * @param authorLastName Author's last name
     * @param yearPublished When the book was originally published
     */
    public Books(String title, double price, String seller, boolean newItem, String authorFirstName, String authorLastName, int yearPublished) {
        super(title, price, seller, newItem);
        this.authorFirstName = authorFirstName;
        this.authorLastName = authorLastName;
        this.yearPublished = yearPublished;
    }

    /**
     * Method to get author's first name
     * @return author's first name
     */
    public String getAuthorFirstName() {
        return authorFirstName;
    }

    /**
     * Method to set author's first name
     * @param authorFirstName author's first name
     */
    public void setAuthorFirstName(String authorFirstName) {
        this.authorFirstName = authorFirstName;
    }

    /**
     * Method to get author's last name
     * @return author's last name
     */
    public String getAuthorLastName() {
        return authorLastName;
    }

    /**
     * Method to set author's last name
     * @param authorLastName author's last name
     */
    public void setAuthorLastName(String authorLastName) {
        this.authorLastName = authorLastName;
    }

    /**
     * Method to get book's publishing year
     * @return book's year published
     */
    public int getYearPublished() {
        return yearPublished;
    }

    /**
     * Method to set book's publishing year
     * @param yearPublished book's year published
     */
    public void setYearPublished(int yearPublished) {
        this.yearPublished = yearPublished;
    }
    /** (old now)
    @Override
    public void display(){
        System.out.println("Title: " + this.getTitle() + "\tSeller: " + this.getSeller());
        System.out.println("Price: $" + this.getPrice());
        System.out.println("New? " + this.isNewItem());
        System.out.println("Author: " + this.getAuthorLastName());
    }
*/
    public String display(){
        return this.getTitle() + " by " + this.getAuthorFirstName() + " " + this.getAuthorLastName() + " (" + this.getYearPublished() + " ($" + this.getPrice() + ")";
    }
    
}
