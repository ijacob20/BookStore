/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jacobisaiahprogrammingckpt4;

/**
 *
 * @author Isaiah
 */
public class PremiumMembers extends Member {
    private String paymentMethod;
    private boolean monthlyFeePaidOnTime;

    /**
     * Constructor for PremiumMembers class
     * @param firstName member's first name
     * @param lastName member's last name
     * @param totalAmountSpent member's total amount spent
     * @param paymentMethod member's payment method
     * @param monthlyFeePaidOnTime whether member's monthly fee is paid on time or not
     */
    public PremiumMembers(String firstName, String lastName, double totalAmountSpent, String paymentMethod, boolean monthlyFeePaidOnTime) {
        super(firstName, lastName, totalAmountSpent);
        this.paymentMethod = paymentMethod;
        this.monthlyFeePaidOnTime = monthlyFeePaidOnTime;
    }

    /**
     * Method to get member's payment method
     * @return paymentMethod
     */
    public String getPaymentMethod() {
        return paymentMethod;
    }

    /**
     * Method to set member's payment method
     * @param paymentMethod member's payment method
     */
    public void setPaymentMethod(String paymentMethod) {
        this.paymentMethod = paymentMethod;
    }

    /**
     * Method to check whether member's monthly fee is paid on time or not
     * @return true or false
     */
    public boolean isMonthlyFeePaidOnTime() {
        return monthlyFeePaidOnTime;
    }

    /**
     * Method to set whether member's monthly fee is paid on time or not
     * @param monthlyFeePaidOnTime if paid on time then true, if not false
     */
    public void setMonthlyFeePaidOnTime(boolean monthlyFeePaidOnTime) {
        this.monthlyFeePaidOnTime = monthlyFeePaidOnTime;
    }
    
    @Override
    /**
    public void display(){
        System.out.println("Name: " + this.getFirstName() + " " + this.getLastName());
        System.out.println("Amount spent: $" + this.getTotalAmountSpent());
        System.out.println("Payment method: " + this.getPaymentMethod());
        System.out.println("Fees paid on time? " + this.isMonthlyFeePaidOnTime());
    }
    */
    public String display() {
        return this.getFirstName() + " " + this.getLastName();
    }
    
    
    @Override
    public void addPurchase(Product product){
        this.totalAmountSpent = this.totalAmountSpent + product.getPrice();
    }
    
    
}
